<template>
  <div>
    <el-table :data="tableData" style="width: 100%">
      <!-- 功能列 -->
      <el-table-column prop="value" label="功能" width="180">
        <template slot-scope="scope">
          <el-select v-model="scope.row.value" placeholder="请选择" size="mini" @change="changeFunc(scope.row)">
            <el-option v-for="(item, index) in funcList" :key="index" :label="item.name" :value="item.value">
            </el-option>
          </el-select>
        </template>
      </el-table-column>

      <!-- 翻转列 -->
      <el-table-column prop="reverse" label="翻转" width="120">
        <template slot-scope="scope">
          <el-switch v-model="scope.row.reverse" @change="changeReverse(scope.row, $event)" size="mini"></el-switch>
        </template>
      </el-table-column>

      <!-- 状态列 -->
      <el-table-column prop="status" label="状态" width="120">
        <template slot-scope="scope">
          <el-switch v-model="scope.row.status" size="mini" disabled></el-switch>
        </template>
      </el-table-column>
    </el-table>

  </div>
</template>

<script>
import { updateParamValue } from "@/api/device/paramValue.js";
import {
  readParam,
  readParams,
  checkDevStatus,
} from "@/api/device/business.js";
export default {
  props: ["param"],
  data() {
    return {
      form: {
        inOut: 0,
        param: null,
        portNum: 0,
        reverse: false,
        status: false,
      },
      queryParams: {
        devId: null,
        ip: null,
        paramSubType: 6,
        pageNum: 1,
        pageSize: 50,
      },
      navTitlePre: "输入端口", // 导航栏标题前缀
      funcList: [],
      funcIndex: 0,
      isBorder: true,
      reverse: false,
      status: false,
      hasChange: false,
      tableData: [],
      ioinFuncList: [
        { name: "无", value: 0 },
        { name: "包装机A请求放料信号输入", value: 1 },
        { name: "包装机B请求放料信号输入", value: 2 },
        { name: "包装机C请求放料信号输入", value: 3 },
        { name: "包装机D请求放料信号输入", value: 4 },
        { name: "料位检测信号输入A", value: 5 },
        { name: "料位检测信号输入B", value: 6 },
        { name: "料位检测信号输入C", value: 7 },
        { name: "料位检测信号输入D", value: 8 },
        { name: "", value: 9 },
        { name: "运行", value: 10 },
      ],
      iooutFuncList: this.generateIooutFuncList(),
      funcList: [], // 功能列表
    };
  },
  created() {
    this.funcList = this.param == 0 ? this.ioinFuncList : this.iooutFuncList;
    this.readData();
  },
  methods: {
    // 读取输入输出参数
    readData() {
      let paramKeys = this.genParamKeys();
      console.log(paramKeys);

      Promise.all([
        readParams({
          devId: this.$store.getters.devId,
          paramKeys: JSON.stringify(paramKeys),
        }),
        readParam({
          devId: this.$store.getters.devId,
          paramKey: this.param == 0 ? "sys_ioin_status" : "sys_ioout_status",
        }),
      ])
        .then(([res1, res2]) => {
          console.log(res1);
          console.log(res2);

          this.tableData = this.createTableData(res1.data, res2.data);
        })
        .catch((error) => {
          console.error(error);
        });
    },
    // 生成paramKeys
    genParamKeys() {
      let paramKeys = [];
      const prefix = this.param == 0 ? "sys_ioin_pin" : "sys_ioout_pin";
      const len = this.param == 0 ? 8 : 16;
      for (let i = 0; i < len; i++) {
        paramKeys.push(prefix + "[" + i + "]");
      }
      return paramKeys;
    },
    // 读取输入输出端口状态
    readStatus() {
      const inState = "sys_ioin_status",
        outState = "sys_ioout_status";
      readParams({
        devId: this.$store.getters.devId,
        paramKeys: JSON.stringify([inState, outState]),
      }).then((res) => {
        console.log(res);
      });
    },
    // 创建tableData
    createTableData(data, status) {
      let tableData = [];
      for (let key in data) {
        tableData.push({
          value: (data[key] & 0x7f) % this.funcList.length,
          reverse: data[key] & 0x80,
          paramKey: key,
          paramValue: data[key],
        });
      }
      tableData = tableData.map((item, i) => {
        item.status = status & (0x01 << i);
        return item;
      });
      console.log(tableData);
      return tableData;
    },
    // 修改端口func
    changeFunc(row) {
      // 将row.value作为row.paramValue的前七位，第八位不变
      row.paramValue = (row.value & 0x7f) | (row.paramValue & 0x80);
      this.saveData(row);
    },
    // 修改输入输出端口状态
    changeReverse(row, b) {
      if (b) {
        row.paramValue = row.paramValue | 0x80;
      } else {
        row.paramValue = row.paramValue & 0x7f;
      }
      this.saveData(row);
    },
    // 保存页面数据
    saveData(pv) {
      // 检测设备是否在线
      checkDevStatus({
        devId: this.$store.getters.devId,
      }).then((res) => {
        if (res.msg != 200) {
          this.$modal.msgError("当前设备" + res.msg);
          return;
        }
        this.$modal.loading("数据正在保存中,请稍后...");
        updateParamValue({
          devId: this.$store.getters.devId,
          paramKey: pv.paramKey,
          paramValue: pv.paramValue,
        })
          .then((res) => {
            console.log(res);
            this.$modal.msgSuccess("保存成功");
            this.$modal.closeLoading();
          })
          .catch((err) => {
            console.log(err);
            this.$modal.closeLoading();
          });
      });
    },
    // 生成iooutFuncList
    generateIooutFuncList() {
      var iooutFuncList = [{ name: "无", value: 0 }];

      for (var i = 1; i <= 5; i++) {
        iooutFuncList.push({
          name: "组合秤就绪 " + i + "A",
          value: (i - 1) * 4 + 1,
        });
        iooutFuncList.push({ name: "放料 " + i + "B", value: (i - 1) * 4 + 2 });
        iooutFuncList.push({ name: "超重 " + i + "C", value: (i - 1) * 4 + 3 });
        iooutFuncList.push({
          name: "料位加料 " + i + "D",
          value: (i - 1) * 4 + 4,
        });
      }

      iooutFuncList.push({ name: "正在运行", value: 21 });
      iooutFuncList.push({ name: "有报警", value: 22 });

      for (var j = 23; j < 30; j++) {
        iooutFuncList.push({ name: "", value: j });
      }

      for (var k = 30; k < 44; k++) {
        iooutFuncList.push({ name: "振机" + (k - 29) + "信号", value: k });
      }

      return iooutFuncList;
    },
  },
};
</script>

<style>
.form-style {
  background-color: #fff;
}

.btn-wrapper {
  margin-top: 20px;
}

.btn-wrapper-button {
  width: 180upx;
  line-height: 80upx;
  height: 80upx;
}
</style>
